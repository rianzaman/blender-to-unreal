﻿// Copyright (c) Viga Entertainment Technology Pvt. ltd. 2022, All rights Reserved

#pragma once
#include<vector>
class PoseFrame
{
public:
    //TMap<FString, FTransform> ObjectName_TransformMap;
    FTransform objectTransform;
    std::vector<TMap<FString, FTransform>> bonevect; // Vector of Maps
    TArray<FString> Subjectname;
    FString SubjectType;
    FString StaticMeshName;
    PoseFrame(TArray<FString> PoseFrameArray);

    /// <summary>
    /// Changes string form of transform to FTransform object (x,y,z,qw,qx,qy,qz,sx,sy,sz) -> FTransform
    /// </summary>
    FTransform ConvertToTransform(FString transformText);
    FTransform ConvertToTransformStaticMesh(FString transformText);
};
